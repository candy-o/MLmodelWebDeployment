import streamlit as st 
import os
import string
import random

#EDA Pkgs
# import pandas as pd 
# import matplotlib.pyplot as plt 
# import matplotlib
# matplotlib.use('Agg')
import joblib

def load_model(model_file):
	loaded_model = joblib.load(open(os.path.join(model_file),"rb"))
	return loaded_model


pswd_vectorizer = open("models/pswd_cv.pkl","rb")
pswd_cv = joblib.load(pswd_vectorizer)

def password_gen(size):
	characters = string.ascii_letters + string.digits + string.punctuation
	generated_pswd = "".join(random.choice(characters) for x in range(size))
	return generated_pswd

def get_key(val,my_dict):
	for key,value in my_dict.items():
		if val == value:
			return key

password_labels = {"weak":0,"good":1,"strong":2}
def main():
	"""Password Strength Classifier"""

	st.title("Password Strength Classifier")

	activies = ["Predictive","Generate","About"]

	choice = st.sidebar.selectbox("Select Task",activies)

	if choice == 'Predictive':
		st.subheader("Predictive Analytics")

		password =  st.text_input("Enter Password","Type here")
		models_list = ["LR","Naive Bayes"]
		model_choice = st.selectbox("Select Model",models_list)
		
		if st.button("Classify"):
			vect_password = pswd_cv.transform([password]).toarray()
			if model_choice == 'LR':
				predictor = load_model("models/logit_pswd_model.pkl")
				prediction = predictor.predict(vect_password)
				
			elif model_choice == 'Naive Bayes':
				predictor = load_model("models/nv_pswd_model.pkl")
				prediction = predictor.predict(vect_password)
			
			final_result = get_key(prediction,password_labels)
			st.info(final_result)
			

	if choice == 'Generate':
		st.subheader("Generate Random Password")
		number = st.number_input("Enter Number",8,25)
		st.write(number)
		if st.button("Generate"):
			custom_password = password_gen(number)
			st.write(custom_password)




if __name__ == '__main__':
		main()	